/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class complex 
{
    int top,arr[20];
    #define Max 4
    public :
             complex() : top(-1){}
             void push();
             void pop();
             void display();
};

void complex :: push()
{
    if(this->top==Max-1)
    {
        cout<<"Stack overflow\n";
        return;
    }
    cout<<"Enter the array element\n";
    cin>>this->arr[++top];
}
void complex:: pop()
{
    if(this->top==-1)
    {
        cout<<"Stack underflow\n";
        return;
    }
    cout<<"The element deleted from the satck is \n";
    cout<<this->arr[top--]<<endl;
}
void complex:: display()
{
    if(top==-1)
    {
        cout<<"Stack is empty\n";
        return;
    }
    for(int i=top;i>=0;i--)
    cout<<this->arr[i]<<endl;
    
}

int main()
{
    int ch;
    complex s;
    for( ; ;)
    {
        cout<<"Enter the choice\n";
        cin>>ch;
        switch(ch)
        {
            case 1 : s.push(); break;
            case 2 : s.pop(); break;
            case 3 : s.display(); break;
            default : exit(0);
        }
    }
}